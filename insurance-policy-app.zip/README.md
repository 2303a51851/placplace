# Insurance Policy Application (Demo)

This repository contains a simple demo web application that allows a user to enter details for an insurance policy and get a quick premium estimate.

## Project structure
```
insurance-policy-app/
 ├── app.js
 ├── package.json
 └── public/
      └── index.html
```

## Run locally
```bash
npm install
npm start
```
Then open http://localhost:3001

## Notes
- This is a demo app and the premium calculation is simplified and for illustrative purposes only.
- Do NOT use it as a real insurance quote.
